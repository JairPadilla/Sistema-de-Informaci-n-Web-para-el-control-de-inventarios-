package com.example.papeleria;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PapeleriaApplication {

	public static void main(String[] args) {
		SpringApplication.run(PapeleriaApplication.class, args);
	}

}
