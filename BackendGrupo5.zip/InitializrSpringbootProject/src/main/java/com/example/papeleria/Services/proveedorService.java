
package com.example.papeleria.Services;

import com.example.papeleria.model.proveedor;
import java.util.List;

public interface proveedorService {
    public proveedor save (proveedor Proveedor);
    public void delete (Integer Id);
    public proveedor findById (Integer Id);
    public List<proveedor> findAll();
    
}
