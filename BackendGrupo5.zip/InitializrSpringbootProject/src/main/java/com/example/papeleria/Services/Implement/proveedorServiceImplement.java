
package com.example.papeleria.Services.Implement;

import com.example.papeleria.Dao.ProveedorDao;
import com.example.papeleria.Services.proveedorService;
import com.example.papeleria.model.proveedor;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
public class proveedorServiceImplement implements proveedorService {
    
    @Autowired
    private ProveedorDao proveedorDao;

    @Override
    
    @Transactional (readOnly = false)
    public proveedor save(proveedor Proveedor) {
       return proveedorDao.save(Proveedor);
    }

    @Override
    @Transactional (readOnly = false)
    public void delete(Integer Id) {
       proveedorDao.deleteById(Id);
    }

    @Override
    @Transactional (readOnly = true)
    public proveedor findById(Integer Id) {
     return proveedorDao.findById(Id).orElse(null);
     
        
    }

    @Override
    @Transactional (readOnly = true)
    public List<proveedor> findAll() {
      return (List<proveedor>) proveedorDao.findAll();
    }
    
}
