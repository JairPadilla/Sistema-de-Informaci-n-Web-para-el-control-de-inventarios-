
package com.example.papeleria.Dao;

import com.example.papeleria.model.proveedor;
import org.springframework.data.repository.CrudRepository;

public interface ProveedorDao extends CrudRepository <proveedor, Integer> {
    
}
