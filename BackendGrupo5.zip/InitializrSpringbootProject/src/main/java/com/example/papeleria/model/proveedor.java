
package com.example.papeleria.model;

import java.io.Serializable;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity 
@Table (name="Proveedor")
public class proveedor implements Serializable{
    @Id 
    @Column(name = "NitProv")
    private Integer NitProv;
    
    @Column(name = "NomProv")
    private String NomProv;
    
    @Column(name = "DirProv")
    private String DirProv;
    
    @Column(name = "TelProv")
    private Integer TelProv;
    
    @Column(name = "CorProv")
    private String CorProv;

    public Integer getNitProv() {
        return NitProv;
    }

    public void setNitProv(Integer NitProv) {
        this.NitProv = NitProv;
    }

    public String getNomProv() {
        return NomProv;
    }

    public void setNomProv(String NomProv) {
        this.NomProv = NomProv;
    }

    public String getDirProv() {
        return DirProv;
    }

    public void setDirProv(String DirProv) {
        this.DirProv = DirProv;
    }

    public Integer getTelProv() {
        return TelProv;
    }

    public void setTelProv(Integer TelProv) {
        this.TelProv = TelProv;
    }

    public String getCorProv() {
        return CorProv;
    }

    public void setCorProv(String CorProv) {
        this.CorProv = CorProv;
    }
    
    
    
}
