package com.example.papeleria.Controlador;

import com.example.papeleria.Services.proveedorService;
import com.example.papeleria.model.proveedor;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@CrossOrigin("*")
@RequestMapping("/proveedor")

public class proveedorControlador {

    @Autowired

    private proveedorService proveedorservice;

    @PostMapping(value = "/")
    public ResponseEntity<proveedor> agregar(@RequestBody proveedor Proveedor) {
        proveedor obj = proveedorservice.save(Proveedor);
        return new ResponseEntity<>(obj, HttpStatus.OK);

    }

    @DeleteMapping(value = "/{Id}")
    public ResponseEntity<proveedor> eliminar(@PathVariable Integer Id) {
        proveedor obj = proveedorservice.findById(Id);

        if (obj != null) {
            proveedorservice.delete(Id);
        } else {
            return new ResponseEntity<>(obj, HttpStatus.INTERNAL_SERVER_ERROR);
        }
        return new ResponseEntity<>(obj, HttpStatus.OK);

    }

    @PutMapping(value = "/")
    public ResponseEntity<proveedor> editar(@RequestBody proveedor Proveedor) {

        proveedor obj = proveedorservice.findById(Proveedor.getNitProv());
        if (obj != null) {
            obj.setNomProv(Proveedor.getNomProv());
            obj.setDirProv(Proveedor.getDirProv());
            obj.setTelProv(Proveedor.getTelProv());
            obj.setCorProv(Proveedor.getCorProv());
            proveedorservice.save(obj);

        } else {
            return new ResponseEntity<>(obj, HttpStatus.INTERNAL_SERVER_ERROR);
        }
        return new ResponseEntity<>(obj, HttpStatus.OK);

    }
    @GetMapping("/list")
    public List <proveedor> consultarTodo(){
        return proveedorservice.findAll();
    } 
    @GetMapping("/list/{Id}")
    
    public proveedor consultaPorId (@PathVariable Integer Id){
        return proveedorservice.findById(Id);
    } 

}
